// Select All Typing Element
const typingEl = document.querySelectorAll('.animate-typing')

// Start Typing Animation
const startTyping = (el) => {
    // Loop All Characters in Element
    [...el.querySelectorAll('span')].every(spanEl => {
        // Unhiding the first hidden span element
        if(spanEl.classList.contains('char-hide')){
            // Unhide Element
            spanEl.classList.remove('char-hide')

            if(el.querySelectorAll('span.char-hide').length == 0){
                /**
                 * Check if all characters are rendered/shown
                 * - If Yes unhide it again after 3s and rerun animation
                 */
                setTimeout(()=>{
                    el.querySelectorAll('span').forEach((spanEL2, i)=>{
                        // Hide only the Charactes and not the cursor element
                        if((i+1) < el.querySelectorAll('span').length)
                        spanEL2.classList.add('char-hide')
                    })
                    // Rerun Animation
                    startTyping(el)
                },3000)
            }else{
                setTimeout(()=>{
                    // Rerun Animation
                    startTyping(el)
                },100)
            }
            return false
        }
        return true
    })
   
}
// Initialize Typing Animation to All Elements that has a Typing Animation Class
typingEl.forEach(el => {
    // Split All Characters
    var elTxtSplit = el.innerText.split("")
    // New Element HTML Content
    var newContent = ``;
    elTxtSplit.forEach(char =>{
        // Update Character enclosed in span element
        newContent += `<span class="char-hide">${char}</span>`;
    })
    // add typing cursor element
     newContent += `<span></span>`;
    //  update the element content with the new content
    el.innerHTML = newContent

    // Start Animation
    startTyping(el)
})
